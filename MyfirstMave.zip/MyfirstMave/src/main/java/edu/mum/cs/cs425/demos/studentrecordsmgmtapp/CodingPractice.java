package edu.mum.cs.cs425.demos.studentrecordsmgmtapp;

public class CodingPractice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CodingPractice cp = new CodingPractice();
   int[]a = {3,5,7,8,9};
  System.out.println(CodingPractice.printWorld(a));
  System.out.println("The Secondlargest = "+ cp.findSecondBiggest(a));
	}
public static StringBuilder printWorld(int[]arr) {
	StringBuilder sp = new StringBuilder();
	
	for(int e : arr) {
		if(e / 5 == 0 && e / 7 == 0)sp.append("HelloWorld" +" ");
		if(e/ 5 == 0)sp.append("Hello" +" ");
		if(e/7 == 0)sp.append("world" +" ");
	}
	return sp;
	
}

public int findSecondBiggest(int[]arr) {
 int secondLargest = (arr[0] >= arr[1])? arr[0]:arr[1];
	 
	 for(int i = 2; i < arr.length; i++) {
		 if(arr[i] > secondLargest) {
			 secondLargest = arr[i];
		 }
	 }
 
	
	return secondLargest;

	
}

}

