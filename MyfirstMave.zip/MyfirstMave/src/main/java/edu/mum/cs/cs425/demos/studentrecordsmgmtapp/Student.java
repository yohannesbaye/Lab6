package edu.mum.cs.cs425.demos.studentrecordsmgmtapp;

import java.time.LocalDate;
import java.util.Date;
import java.util.GregorianCalendar;

public class Student {
 private String studentId;
 private String name;
 private LocalDate dateOfAdmission;
 
 public Student(String Id, String name, /*GregorianCalendar */LocalDate admissionDate) {
	 studentId = Id;
	 this.name = name;
	 dateOfAdmission = admissionDate;
	 
 }

public String getStudentId() {
	return studentId;
}

public void setStudentId(String studentId) {
	this.studentId = studentId;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public LocalDate getDateOfAdmission() {
	return dateOfAdmission;
}

public void setDateOfAdmission(LocalDate dateOfAdmission) {
	this.dateOfAdmission = dateOfAdmission;
}
public String toString() {
	return "StudetnId: "+ studentId + " Name:"+ name +" dateOfAdmission: "+ dateOfAdmission;
}

}

