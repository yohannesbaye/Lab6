package edu.mum.CS425.eRegistrarWebAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ERegistrarWebApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
