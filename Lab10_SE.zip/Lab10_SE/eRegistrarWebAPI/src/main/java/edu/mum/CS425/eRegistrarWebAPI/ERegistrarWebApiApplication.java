package edu.mum.CS425.eRegistrarWebAPI;

import java.time.LocalDate;
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import edu.mum.CS425.eRegistrarWebAPI.Repository.StudentRepository;
import edu.mum.CS425.eRegistrarWebAPI.entity.Student;


@SpringBootApplication
public class ERegistrarWebApiApplication  implements CommandLineRunner{
	
	@Autowired
	private StudentRepository studentRepository;

	@Override
	public void run(String ...strings)throws Exception {
Student st1 = new Student("000-61-0001", "Anna", "Minalachew", "Smith", 3.78, LocalDate.of(2019,5,12		), false);
		Student st2 = new Student("000-61-0002", "Nahoem", "Simeneh", "Endalew", 4.00, LocalDate.of(2020,02,01), false);
		Student st3 = new Student( "000-61-0003", "Woreta", "Mulualem", "henok", 3.85, LocalDate.of(2020,02,01), false);
		Student st4 = new Student("000-61-0004", "Walcot", "Henry", "Goerge", 4.00, LocalDate.of(2020,02,01), false);
		Student st5 = new Student("000-61-0005 ", "Mulew", "Minalachew", "beya", 3.85, LocalDate.of(2020,02,01), false);
		Student st6 = new Student("000-61-0006", "Nahoem", "Simeneh", "Endalew", 4.00, LocalDate.of(2020,02,01), false);
		Student st7 = new Student("000-61-0007", "Durie", "Sitotaw", "Tebebew", 3.85, LocalDate.of(2020,02,01), true);
		Student st8 = new Student("000-61-0008", "Gebiyaw", "Alemu", "Negash", 3.00, LocalDate.of(2020,02,01), false);
		Student st9 = new Student("000-61-0009", "Fikadu", "Minalachew", "Dagnaw", 3.85, LocalDate.of(2020,02,01), true);
		Student st10 = new Student("000-61-0010 ", "Atinaf", "Getu", "Beyen", 2.00, LocalDate.of(2020,02,01), false);
		Student st11 = new Student("000-61-0011 ", "Lewtu", "Yeshanew ", "Damitie", 3.85, LocalDate.of(1987,10,9), true);
		Student st12 = new Student("000-61-0012 ", "Melkamu", "Belachew", "Alamir", 3.00, LocalDate.of(1990,02,11), false);
		 
		studentRepository.saveAll(Arrays.asList(st1, st2, st3, st4,st5, st6,st7,st8,st9,st10,st11,st12));
	}


	public static void main(String[] args) {
		SpringApplication.run(ERegistrarWebApiApplication.class, args);
	}
	


	public Student saveStudent(Student student) {
		return studentRepository.save(student);
	}
}


