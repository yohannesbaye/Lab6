package edu.mum.CS425.eRegistrarWebAPI.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import edu.mum.CS425.eRegistrarWebAPI.entity.Student;


@Service
public interface StudentService {
	public List<Student> getAllStudents();

	public Student registerNewStudent(Student newStudent);

	public Student getStudentByIdById(Integer studentId);

	public Student updateStudent(Student editedStudent, Integer id);

	public void deleteStudent(Integer stID);

}
