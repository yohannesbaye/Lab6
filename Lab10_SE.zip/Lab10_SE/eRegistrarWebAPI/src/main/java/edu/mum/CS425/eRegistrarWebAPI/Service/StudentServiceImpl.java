package edu.mum.CS425.eRegistrarWebAPI.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.mum.CS425.eRegistrarWebAPI.Repository.StudentRepository;
import edu.mum.CS425.eRegistrarWebAPI.entity.Student;



@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository studentRepository; 
	
	@Override
	public List<Student> getAllStudents(){
		return studentRepository.findAll();
		
		
	}
	@Override
	public Student registerNewStudent(Student newStudent) {
		return studentRepository.save(newStudent);
	}
	@Override
	public Student getStudentByIdById(Integer studentId) {
		return studentRepository.findById(studentId).orElse(null);
	}
	
	@Override
	public Student updateStudent(Student editedStudent, Integer id) {
		Optional<Student> studentOld = studentRepository.findById(id);
		if(studentOld.isPresent()) {
			// Update all properties except id
			editedStudent.setStudentId(studentOld.get().getStudentId());
			return studentRepository.save(editedStudent);
		}
		else {
			//	Insert for new recored
			return studentRepository.save(editedStudent);
		}
		
//		return studentRepository.findById(id).map(st ->{
//			st.setfName(editedStudent.getfName().setmName(editedStudent.getmName()
//					.setlName(editedStudent.getlName().setcgpa(editedStudent.getCgpa()
//							.setenrollmentDate(editedStudent.getEnrollmentDate()
//								.setisInternationalinternational(editedStudent.getIsInternational()))))))
//			                         .editedStudentStudeNTRepository.save(st); })
//					.orElseGet(()->{
//						return studentRepository.save(editedStudent);
//					});	
	}
	
	
	
	@Override
	public void deleteStudent(Integer stID) {
		studentRepository.deleteById(stID);
		
		
	}

	
}
