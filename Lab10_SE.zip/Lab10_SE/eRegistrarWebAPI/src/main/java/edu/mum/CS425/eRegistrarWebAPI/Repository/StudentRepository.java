package edu.mum.CS425.eRegistrarWebAPI.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.mum.CS425.eRegistrarWebAPI.entity.Student;

public interface StudentRepository extends JpaRepository<Student, Integer>{

}
