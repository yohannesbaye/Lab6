

//Question
//2. Add a new entity named, Classroom (classroomId: primaryKey, buildingName, roomNumber) 
//to your solution above. Determine the relationship between Student entity and Classroom entity.
//And then implement JPA code for mapping and persisting/saving a student-and-classroom object
//data. Sample data: Classroom {1, "McLaughlin building", "M105"}

package edu.mum.cs.cs425.JPA.MyStudentMgmtApp.Assignment.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import java.util.List;

@Entity
@Table(name = "ClassRoom")
public class ClassRoom {
	@Id
   @GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long classRoomiD;
	
	private String name;
	private String classNumber;
	
//	@OneToMany(mappedBy = "ClassRoom")
//	private List students;
	
	
	public ClassRoom() {
		super();
	}
	public ClassRoom(String name, String classNumber) {
		super();
		this.name = name;
		this.classNumber = classNumber;
	
	}
	public ClassRoom(String name, String classNumber, List<Student>st) {
		super();
		this.name = name;
		this.classNumber = classNumber;
		List<Student>students = st;
		}
	public Long getClassRoomiD() {
		return classRoomiD;
	}
	public void setClassRoomiD(Long classRoomiD) {
		this.classRoomiD = classRoomiD;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getClassNumber() {
		return classNumber;
	}
	public void setClassNumber(String classNumber) {
		this.classNumber = classNumber;
	}
//	public List<Student> getStudents() {
//		return students;
//	}
//	public void setStudents(List<Student> students) {
//		this.students = students;
//	}
	@Override
	public String toString() {
		return "ClassRoom [classRoomiD=" + classRoomiD + ", name=" + name + ", classNumber=" + classNumber
				+ " ]";
	}
	
	

}
