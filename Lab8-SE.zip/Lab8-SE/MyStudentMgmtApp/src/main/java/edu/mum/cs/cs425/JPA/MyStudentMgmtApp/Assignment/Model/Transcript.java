package edu.mum.cs.cs425.JPA.MyStudentMgmtApp.Assignment.Model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "transcript")
public class Transcript {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long transcriptId;
	
	private String degreetitle;

	// @OneToOne(mappedBy = "student")
	// @OneToOne( cascade = CascadeType.persist);
       @OneToOne(cascade = CascadeType.PERSIST)
	 // @JoinColumn(name="degreeOwner", nullable = false)
	private Student degreeOwner;
	

public Transcript() {
	super();
}

public Transcript( String degree, Student st) {
	degreetitle = degree; 
	degreeOwner = st;
}

public void setDegreeOwner(Student degreeOwner) {
	this.degreeOwner = degreeOwner;	
}
public Student getDegreeOwner() {
	return degreeOwner;
}
	public Long getTranscriptId() {
		return transcriptId;
	}

	public void setTranscriptId(Long transcriptId) {
		this.transcriptId = transcriptId;
	}

	public String getDegreetitle() {
		return degreetitle;
	}

	public void setDegreetitle(String degreetitle) {
		this.degreetitle = degreetitle;
	}
	
	

}
