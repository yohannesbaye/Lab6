package edu.mum.cs.cs425.JPA.MyStudentMgmtApp.Assignment.Model;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "student")
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Student_id")
	private Long studentd;

	// @NotBlank(message = "booknumber is required")
	@Column(name = "isbn", unique = true, nullable = false)
	private String studentNumber;

	@Column(nullable = false)
	private String firstName; // : (required) (e.g. Data values: "Anna", "Bob" etc.)

	// @Column(name = "mName", nullable = true)
	private String middleName; // (is Optional

	// @Column(name = "lName", nullable = false)
	private String lastName; // (required)

	// @Column(name ="Commulative_GPA")
	private Double cgpa; // : (is optional)

	// @Column(name = "dateOfEnrollment")
	private LocalDate dateOfEnrollment;

	// creating relation between student and transcript. one transcript belongs to
	// one student and vice-versa.
	@OneToOne(cascade = CascadeType.PERSIST)
	// @JoinColumn(name = "transcripttype")
	private Transcript transcript;

	// crate relation between class and student. many student in one class.
	@ManyToOne(cascade = CascadeType.PERSIST)
	// @JoinColumn(name = "classRoomId")
	private ClassRoom room;

	// Here is Constructores.
	public Student() {
		super();
	}

	public Student(String studentNumber, String firstName, String middleName, String lastName, Double cgpa,
			LocalDate dateOfEnrollment) {
		super();
		this.studentNumber = studentNumber;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.cgpa = cgpa;
		this.dateOfEnrollment = dateOfEnrollment;
		// this.transcript = transcript;
	}

	public Student(String studentNumber, String firstName, String middleName, String lastName, Double cgpa,
			LocalDate dateOfEnrollment, Transcript transcipt) {
		super();
		this.studentNumber = studentNumber;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.cgpa = cgpa;
		this.dateOfEnrollment = dateOfEnrollment;
		this.transcript = transcript;
	}

	public Long getStudentd() {
		return studentd;
	}

	public void setStudentd(Long studentd) {
		this.studentd = studentd;
	}

	public String getStudentNumber() {
		return studentNumber;
	}

	public void setStudentNumber(String studentNumber) {
		this.studentNumber = studentNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Double getCgpa() {
		return cgpa;
	}

	public void setCgpa(Double cgpa) {
		this.cgpa = cgpa;
	}

	public LocalDate getDateOfEnrollment() {
		return dateOfEnrollment;
	}

	public void setDateOfEnrollment(LocalDate dateOfEnrollment) {
		this.dateOfEnrollment = dateOfEnrollment;
	}

	public Transcript getTranscript() {
		return transcript;
	}

	public void setTranscript(Transcript transcript) {
		this.transcript = transcript;
	}

	public ClassRoom getRoom() {
		return room;
	}

	public void setRoom(ClassRoom room) {
		this.room = room;
	}

	@Override
	public String toString() {
		return "Student [studentd=" + studentd + ", studentNumber=" + studentNumber + ", firstName=" + firstName
				+ ", middleName=" + middleName + ", lastName=" + lastName + ", cgpa=" + cgpa + ", dateOfEnrollment="
				+ dateOfEnrollment + ", transcript=" + transcript + ", room=" + room + "]";
	}

}
