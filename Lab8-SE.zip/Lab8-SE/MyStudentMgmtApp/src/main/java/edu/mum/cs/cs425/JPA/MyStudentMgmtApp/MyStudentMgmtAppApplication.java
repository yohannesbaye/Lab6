package edu.mum.cs.cs425.JPA.MyStudentMgmtApp;
//import edu.mum.cs.cs425.JPA.MyStudentMgmtApp.Assignment.Model;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import edu.mum.cs.cs425.JPA.MyStudentMgmtApp.Assignment.Model.ClassRoom;
import edu.mum.cs.cs425.JPA.MyStudentMgmtApp.Assignment.Model.Student;
import edu.mum.cs.cs425.JPA.MyStudentMgmtApp.Assignment.Model.Transcript;

@SpringBootApplication
public class MyStudentMgmtAppApplication implements CommandLineRunner {
	@Autowired
	
	private StudentRepository studentRepository;
	@Override
 public void run(String ...strings)throws Exception {
		//student and Transcript relationship is here.
	Student student1 = new Student(" 000-61-0001", "Anna", "Lynn", "Smith", 3.45, LocalDate.of(2019,5,24));
	Student student2 = new Student(" 000-61-0002", "Yohannes", "Bekalu", "Woreta", 3.85, LocalDate.of(2019,6,24));
	Student student3 = new Student(" 000-61-0003", "Kirubel", "Amare", "Henock", 3.45, LocalDate.of(2019,5,24));
	Student student4 = new Student(" 000-61-005", "John", "Mistofa", "Taha", 3.85, LocalDate.of(2019,6,24));
	Transcript transcript1 = new Transcript("BS Computer Science", student1);
	Transcript transcript2 = new Transcript("Masterso f bussines science", student2);
	Transcript transcript3 = new Transcript("Advanced software development", student3);
	Transcript transcript4 = new Transcript("Bachelor of Art", student4);
	student1.setTranscript(transcript1);
	student2.setTranscript(transcript2);
	student3.setTranscript(transcript3);
	student4.setTranscript(transcript4);
		
	//student and ClassRoom relationship is here.
//	 List<Student>studentCatagory1 = Arrays.asList(student1,student2);
//	 List<Student>studentCatagory2 = Arrays.asList(student3,student4);
		ClassRoom room1= new ClassRoom("McLaughlin building", "M105");
		ClassRoom room2= new ClassRoom("McLaughlin building", "M110");
		//ClassRoomroom2 = new ClassRoom("McLaughlin building", "M105", student2);
		
		student1.setRoom(room1);
		student2.setRoom(room1);
		student3.setRoom(room2);
		student4.setRoom(room2);
		studentRepository.saveAll(Arrays.asList(student1, student2, student3, student4));
//		studentRepository.save(student1);
//		studentRepository.save(student2);
//		studentRepository.save(student3);
//		studentRepository.save(student4);
					
	
 }
	public static void main(String[] args) {
		SpringApplication.run(MyStudentMgmtAppApplication.class, args);
	}
	

private Student saveStudent(Student student) {
	return studentRepository.save(student);
}
}
