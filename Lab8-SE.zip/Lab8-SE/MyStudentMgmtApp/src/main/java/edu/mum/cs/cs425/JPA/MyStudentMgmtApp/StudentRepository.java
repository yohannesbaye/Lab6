package edu.mum.cs.cs425.JPA.MyStudentMgmtApp;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import edu.mum.cs.cs425.JPA.MyStudentMgmtApp.Assignment.Model.Student;
@Repository
public interface StudentRepository extends CrudRepository<Student, String> {
	


}
