package edu.mum.cs.cs425.JPA.MyStudentMgmtApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyStudentMgmtAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
