package eduedu.miu.LabAssignment_11.Array.Test;

import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import eduedu.miu.LabAssignment_11.Array.ArrayFlattener;

public class ArrayFlattenerTest {
 private 	ArrayFlattener arrayFlatten;
	@Before
	public void setUp() throws Exception {
		this.arrayFlatten = new ArrayFlattener();
	}

	@After
	public void tearDown() throws Exception {
		this.arrayFlatten = null;
	}

	@Test
	public void test() {
		Integer[][]arr = {{1,3}, {0}, {4,5,9}};
		Integer[]expected = {1, 3, 0, 4, 5, 9};
		Integer[] expected2 = {9,5,4,0,3,1};
		//Assert.assertArrayEquals(expected, arrayFlatten.flattenArray(arr));
		Assert.assertArrayEquals(expected2, arrayFlatten.reverseArray(arr));
	} 
	
	/*
	@Test
	public void testforOneValue() {
		Integer[][]arr = {{0}};
		Integer[]expected = {0};
		Assert.assertArrayEquals(expected, arrayFlatten.flattenArray(arr));
	}
	*/

}
