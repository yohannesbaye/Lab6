package eduedu.miu.LabAssignment_11.Array.Test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ ArrayFlattenerTest.class, ArrayFlattenerTest2.class })
public class AllTests {

}
