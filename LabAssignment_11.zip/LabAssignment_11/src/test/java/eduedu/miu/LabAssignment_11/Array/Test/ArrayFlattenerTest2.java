package eduedu.miu.LabAssignment_11.Array.Test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import eduedu.miu.LabAssignment_11.Array.ArrayFlattener;

public class ArrayFlattenerTest2 {

	 private 	ArrayFlattener arrayFlatten;
		@Before
		public void setUp() throws Exception {
			this.arrayFlatten = new ArrayFlattener();
		}

		@After
		public void tearDown() throws Exception {
			this.arrayFlatten = null;
		}

	@Test
   public void testforNull() {
			Integer[][]arr = null;
			Integer[]expected = null;
			Assert.assertArrayEquals(expected, arrayFlatten.flattenArray(arr));
		}
	}


