package eduedu.miu.LabAssignment_11.Array;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


public class ArrayFlattener {

	public static Object[]  flattenArray(Integer[][]arr) {
		if(arr != null) {
	   List<Integer>list1= (List<Integer>) Arrays.stream(arr).flatMap(x->Arrays.stream(x)).collect(Collectors.toList());
	   return  list1.toArray();
		}
		return null;
		
	 }
	
public static Integer[] reverseArray(Integer[][] arr) {
		
	if(arr == null)return null;
	  List<Integer>list2 = (List<Integer>) Arrays.stream(arr).flatMap(x->Arrays.stream(x)).collect(Collectors.toList());
	  Integer[]arr2 = new Integer[list2.size()];
	  for(int i = list2.size() - 1, j = 0; i >= 0; i--, j++) {
		  arr2[j] = list2.get(i);
	 //  return  (Integer[]) str2.;
		}
		return arr2;
		
	 }
      
	
public static void main(String[]arg) {
	
	Integer[][]a = {{1,3}, {0}, {4,5,9}};
	Object[] flat = reverseArray(a);
	Integer[][]a2 =  {{1}};


	Object[] flat2 = flattenArray(a2);
	

	System.out.println(Arrays.asList(flat));
	System.out.println(Arrays.asList(flat2));
	
}
}
