package edu.mum.cs.cs425.eRegistralApp.Service;


import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.repository.CrudRepository;

import edu.mum.cs.cs425.eRegistralApp.Model.Student;

public interface StudentService {
     Iterable<Student>getAllStudents();
    
     public  Page<Student> getAllStudentpages(int pageNo);
    public abstract List<Student> searchStudents(String str);
    public abstract Student saveStudent(Student student);
    public abstract Student getStudentById(Integer studentId);
    public abstract void deleteStudentsById(Integer studentId);


}