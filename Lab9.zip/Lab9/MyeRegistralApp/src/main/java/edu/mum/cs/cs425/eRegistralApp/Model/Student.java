package edu.mum.cs.cs425.eRegistralApp.Model;


import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.format.annotation.DateTimeFormat;
 @Entity
public class Student {
     @Id
     @GeneratedValue(strategy = GenerationType.IDENTITY)
     @Column(name = "Student_id", nullable = false)
    private Integer studentId;
     
    private String fName;
    private String mName;
    private String lName;
    
    
    private double cgpa;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate enrollmentDate;
    private Boolean isInternational;
  
     public Student(String fName, String mName, String lName, double cgpa, LocalDate enrollmentDate, Boolean isInternational) {
         this.fName = fName;
         this.mName = mName;
         this.lName = lName;
         this.cgpa = cgpa;
         this.enrollmentDate = enrollmentDate;
         this.isInternational = isInternational;
     }
     public Student(){

     }
	public Integer getStudentId() {
		return studentId;
	}
	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getmName() {
		return mName;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public double getCgpa() {
		return cgpa;
	}
	public void setCgpa(double cgpa) {
		this.cgpa = cgpa;
	}
	public LocalDate getEnrollmentDate() {
		return enrollmentDate;
	}
	public void setEnrollmentDate(LocalDate enrollmentDate) {
		this.enrollmentDate = enrollmentDate;
	}
	public Boolean getIsInternational() {
		return isInternational;
	}
	public void setIsInternational(Boolean isInternational) {
		this.isInternational = isInternational;
	}
	
   
 }


//   studentId : (should be the primary key field)
//           studentNumber: e.g. 000-61-0001 (required)
//           FirstName: e.g. Anna (required)
//           MiddleName: (optional)
//           LastName: e.g. Smith (required)
//           cgpa: e.g. 3.78 (optional)
//           enrollmentDate: e.g. 2019-5-12 (required)
//           isInternational: (values: "Yes", "No") (required) - Hint: Implement/present this data in a drop-down list or Radio button
