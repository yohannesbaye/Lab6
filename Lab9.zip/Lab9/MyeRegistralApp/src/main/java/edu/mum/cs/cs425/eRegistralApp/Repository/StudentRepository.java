package edu.mum.cs.cs425.eRegistralApp.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.mum.cs.cs425.eRegistralApp.Model.Student;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

public interface StudentRepository  extends JpaRepository<Student,Integer> {
	
	/*
	  List<Student> findAllByfNameContainingOrfNameContainingOrstudentsContainingOrderByfName(Integer studentId,
	 
            String fName,
            String lName);
            */
//List<Student> findAllByCGPA(Double CPGA);
//List<Student>findAllByDatePublishedEquals(LocalDate enrollmentDate);

// More queries
//List<Book> findBooksByDatePublishedIsStartingWith(String str);
}