package edu.mum.cs.cs425.eRegistralApp.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomePageContrller {

	@GetMapping(value = { "/", "/home", "/eRegistral" })
	public String show() {
		return "home/index";
	}
}
