package edu.mum.cs.cs425.eRegistralApp.Service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import edu.mum.cs.cs425.eRegistralApp.Model.Student;
import edu.mum.cs.cs425.eRegistralApp.Repository.StudentRepository;


@Service
public class StudentServiceImpl implements StudentService {
	
    @Autowired
    private StudentRepository repository;
  
    int size;
    @Override
    public List<Student> getAllStudents() {
        return (List<Student>)repository.findAll();
    }
    
    @Override
    public  Page<Student> getAllStudentpages(int pageNo) {
        return repository.findAll(PageRequest.of(pageNo, 3, Sort.by("fName")));
    }
    
    
    @Override
    public Student saveStudent(Student student) {
        return repository.save(student);
    }
    
    @Override
    public List<Student> searchStudents(String str) {
    	
    	String query = str.toLowerCase();
    	List<Student> students = getAllStudents();
    	students = students.stream()
    			.filter(s -> s.getfName().toLowerCase().contains(query) || s.getmName().toLowerCase().contains(query) || s.getlName().toLowerCase().contains(query)).collect(Collectors.toList());
    	return students;
    }
    
    @Override
    public Student getStudentById(Integer studentId) {
        return repository.findById(studentId).orElse(null);
    }

   
    @Override
    public void deleteStudentsById(Integer studentId) {
        repository.deleteById(studentId);
    }


}
