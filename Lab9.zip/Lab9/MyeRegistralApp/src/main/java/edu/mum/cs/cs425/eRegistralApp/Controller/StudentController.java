package edu.mum.cs.cs425.eRegistralApp.Controller;

import java.util.Collection;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import edu.mum.cs.cs425.eRegistralApp.Model.Student;
import edu.mum.cs.cs425.eRegistralApp.Service.StudentService;

@Controller
public class StudentController  {

	@Autowired
	private StudentService studentService;

    
    @GetMapping(value = {"/eRegistral/student/list","/student/list"})
   public ModelAndView listStudents(@RequestParam(defaultValue = "0") int pageno) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("students", studentService.getAllStudentpages(pageno));
        modelAndView.addObject("currentPageNo", pageno);
        modelAndView.setViewName("student/list");
        return modelAndView;
   }
    
    
    
    
    @GetMapping(value = {"/eRegistral/student/new","/student/new"})
    public String displayNewStudentForm(Model model) {
        model.addAttribute("student", new Student());
        return "student/new";
    }

    @PostMapping(value = {"/eRegistral/student/new","/student/new"})
    public String addNewStudent(@Valid @ModelAttribute("student") Student student,
                                     BindingResult bindingResult, Model model) {
    	
        if (bindingResult.hasErrors()) {
            model.addAttribute("errors", bindingResult.getAllErrors());
            System.out.println(bindingResult);
            System.out.println(student);
            return "student/new";
        }
        student = studentService.saveStudent(student);
        return "redirect:/eRegistral/student/list";
    }

    @GetMapping(value = {"/eRegistral/student/edit/{studentId}","/student/edit/{studentId}"})
    public String editStudent(@PathVariable Integer studentId, Model model) {
        Student student = studentService.getStudentById(studentId);
        System.out.println(student);
        if (student != null) {
            model.addAttribute("student", student);
            return "student/edit";
        }
        return "student/list";
    }

    @PostMapping(value = {"/eRegistral/student/edit/{studentId}","/student/edit/{studentId}"})
    public String updateStudent(@Valid @ModelAttribute("student") Student student, @PathVariable Integer studentId,
                                BindingResult bindingResult, Model model) {
    	
        if (bindingResult.hasErrors()) {
            model.addAttribute("errors", bindingResult.getAllErrors());
            return "student/edit";
        }
        studentService.deleteStudentsById(studentId);
        student  = studentService.saveStudent(student);
        return "redirect:/eRegistral/student/list";
    }

    @GetMapping(value = {"/eRegistral/student/delete/{studentId}","/student/delete/{studentId}"})
    public String deleteStudent(@PathVariable Integer studentId, Model model) {
        studentService.deleteStudentsById(studentId);
        return "redirect:/eRegistral/student/list";
    }

    @GetMapping(value = {"/eRegistral/students/search", "/students/search"})
    public ModelAndView searchStudents(@RequestParam String searchString) {
        ModelAndView modelAndView = new ModelAndView();
        List<Student> students = studentService.searchStudents(searchString);
        modelAndView.addObject("students", students);
        modelAndView.addObject("studentsCount", students.size());
        modelAndView.addObject("searchString", searchString);
                                         
        modelAndView.setViewName("student/search");
        return modelAndView;
    }

}