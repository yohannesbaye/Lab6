package edu.mum.cs.cs425.eRegistralApp;

import java.time.LocalDate;
import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import edu.mum.cs.cs425.eRegistralApp.Model.Student;
import edu.mum.cs.cs425.eRegistralApp.Repository.StudentRepository;

@SpringBootApplication
public class MyeRegistralAppApplication implements CommandLineRunner {
	@Autowired
	private StudentRepository studentRepository;

	@Override
	public void run(String ...strings)throws Exception {
		Student st1 = new Student("Yohannes", "Minalachew", "beya", 3.85, LocalDate.of(2020,02,01), false);
		Student st2 = new Student("Nahoem", "Simeneh", "Endalew", 4.00, LocalDate.of(2020,02,01), false);
		Student st3 = new Student("Woreta", "Mulualem", "henok", 3.85, LocalDate.of(2020,02,01), false);
		Student st4 = new Student("Walcot", "Henry", "Goerge", 4.00, LocalDate.of(2020,02,01), false);
		Student st5 = new Student("Mulew", "Minalachew", "beya", 3.85, LocalDate.of(2020,02,01), false);
		Student st6 = new Student("Nahoem", "Simeneh", "Endalew", 4.00, LocalDate.of(2020,02,01), false);
		Student st7 = new Student("Durie", "Sitotaw", "Tebebew", 3.85, LocalDate.of(2020,02,01), true);
		Student st8 = new Student("Gebiyaw", "Alemu", "Negash", 3.00, LocalDate.of(2020,02,01), false);
		Student st9 = new Student("Fikadu", "Minalachew", "Dagnaw", 3.85, LocalDate.of(2020,02,01), true);
		Student st10 = new Student("Atinaf", "Getu", "Beyen", 2.00, LocalDate.of(2020,02,01), false);
		Student st11 = new Student("Lewtu", "Yeshanew ", "Damitie", 3.85, LocalDate.of(1987,10,9), true);
		Student st12 = new Student("Melkamu", "Belachew", "Alamir", 3.00, LocalDate.of(1990,02,11), false);
		 
		studentRepository.saveAll(Arrays.asList(st1, st2, st3, st4,st5, st6,st7,st8,st9,st10,st11,st12));
	}

	public static void main(String[] args) {
		SpringApplication.run(MyeRegistralAppApplication.class, args);
	}

	public Student saveStudent(Student student) {
		return studentRepository.save(student);
	}
}
